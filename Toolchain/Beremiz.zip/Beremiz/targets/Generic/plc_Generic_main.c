/**
 * No platform specific code for "Generic" target
 **/

