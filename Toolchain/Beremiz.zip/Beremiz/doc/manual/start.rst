Start a new automation project
==============================
