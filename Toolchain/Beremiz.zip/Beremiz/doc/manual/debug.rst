Trace POUs instances variable
=============================
