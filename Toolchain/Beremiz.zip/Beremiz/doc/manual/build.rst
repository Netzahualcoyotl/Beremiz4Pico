Build PLC executable binary
===========================
