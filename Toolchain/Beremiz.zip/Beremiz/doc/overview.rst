Project overview
================

In order to target the widest possible range of programmable devices and keep efficient, Beremiz use C code as an intermediate language. 

To be executed, C needs to be compiled. `GCC <http://gcc.gnu.org>`_ serve that purpose perfectly.

PLC program is expressed in languages defined in IEC-61131, including graphical languages. Thanks to PLCopen TC2, those graphical languages have a standardised representation, in XML.

To be continued.
